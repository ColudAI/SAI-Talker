document.addEventListener('DOMContentLoaded', () => {
    // 获取切换按钮
       // 获取ID为'load'的div元素
    const loads = document.getElementById('loadings');
    const cba = document.getElementById('cb');
    const body = document.body;

    // 定义切换模式的函数
    function toggleMode() {
        if (body.classList.contains('night-mode')) {
            // 切换到白天模式
            loads.style.borderColor = '#000000';
            body.classList.remove('night-mode');
            body.classList.add('day-mode');
            cba.checked = false;
        } else {
            // 切换到黑夜模式
            loads.style.borderColor = '#ffffff';
            body.classList.remove('day-mode');
            body.classList.add('night-mode');
            cba.checked = true;
        }
    }

    // 为切换按钮绑定点击事件
    if (cba) {
        cba.addEventListener('change', toggleMode);
    }

    // 初始化模式
    if (cba.checked) {
        body.classList.add('night-mode');
    } else {
        body.classList.add('day-mode');
    }
});