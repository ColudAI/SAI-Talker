
document.addEventListener("DOMContentLoaded", () => {

    const inputTextElement = document.getElementById('user-input');
    const askBtn = document.getElementById('ask-btn');
    chrome.storage.sync.get('selectedText', ({ selectedText }) => {
        if (selectedText) {
            inputTextElement.value = selectedText;

            console.log('成功使用选择的文本');// 清除selectedText的内容
            chrome.storage.sync.set({ selectedText:'' });
 const toast = document.createElement('div');
 toast.className = 'fixed bottom-4 right-4 bg-gray-800 text-white px-6 py-3 !rounded-button shadow-lg transform transition-all duration-500 opacity-0 translate-y-2';
 toast.textContent = '✨ 成功使用选择的文本内容';
 document.body.appendChild(toast);
 setTimeout(() => {
 toast.classList.remove('opacity-0', 'translate-y-2');
 }, 100);
 setTimeout(() => {
 toast.classList.add('opacity-0', 'translate-y-2');
 setTimeout(() => toast.remove(), 500);
 }, 3000);


        } else {
            console.error('获取选中文本失败。');
            
        }

             
            
   
});
});