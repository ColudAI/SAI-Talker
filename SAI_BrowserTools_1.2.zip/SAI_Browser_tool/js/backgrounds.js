// background.js
chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
        id: "askSai",
        title: "问问SAI，帮您拿定主意！",
        contexts: ["selection"]
    });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "askSai" && info.selectionText) {
        chrome.storage.sync.set({ selectedText: info.selectionText });
        chrome.tabs.create({ url: chrome.runtime.getURL("popup.html") });
    }
});

// 监听来自内容脚本的消息
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (message.action === 'ask') {
        // 显示选中的文本
        document.getElementById('user-input').textContent = message.text;
    }
});

