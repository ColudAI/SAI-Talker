   // 初始化语速
   let speechRate = 1;

   // 朗读文本
   function speakText(text) {
       // 创建一个新的 SpeechSynthesisUtterance 对象
       var utterance = new SpeechSynthesisUtterance(text);
   
       // 设置语音合成的属性
       utterance.lang = 'zh-CN'; // 设置语言为中文
       utterance.rate = 1; // 设置语速
       utterance.pitch = 1; // 设置音调
       utterance.volume = 1; // 设置音量
   
       // 播放语音
       window.speechSynthesis.speak(utterance);
   }


document.addEventListener("DOMContentLoaded", () => {




   const titles = document.getElementById('title');
    let url = "https://ai.coludai.cn/api/chat"; // 初始值
    console.log("当前目标地址:", url);
    const ais = document.getElementById('aititle');
    const thinkingButton = document.getElementById('thinking');
    thinkingButton.addEventListener('click', () => {
        url = 'https://reasoner.coludai.cn/api/illation'; // 修改变量url的值为0
        console.log("已启动深度思考节点 测试版");
        titles.textContent = "SAI-L6 Reasoner";
        ais.textContent = `你好我是SAI-L6 深度思考版本
        我会写代码，深度解答问题，您告诉我问题，我会尽力帮您实现！( •̀ ω •́ )✧`;
        const toast = document.createElement('div');
        toast.className = 'fixed bottom-4 right-4 bg-gray-800 text-white px-6 py-3 !rounded-button shadow-lg transform transition-all duration-500 opacity-0 translate-y-2';
        toast.textContent = '✨ SAI-Reasoner 已启动 ( •̀ ω •́ )✧';
        document.body.appendChild(toast);
        setTimeout(() => {
        toast.classList.remove('opacity-0', 'translate-y-2');
        }, 100);
        setTimeout(() => {
        toast.classList.add('opacity-0', 'translate-y-2');
        setTimeout(() => toast.remove(), 500);
        }, 3000);
    });

    const L6Mode = document.getElementById('l6mode');
    L6Mode.addEventListener('click', () => {
        url = 'https://ai.coludai.cn/api/chat'; // 修改变量url的值为0
        console.log("已启动SAI-L6");
        ais.textContent = "你好我是SAI-L6\n我会写代码，解答问题，你告诉我，我会尽力帮您实现！ヾ(≧▽≦*)o";
        titles.textContent = "SAI-L6";
        const toast = document.createElement('div');
        toast.className = 'fixed bottom-4 right-4 bg-gray-800 text-white px-6 py-3 !rounded-button shadow-lg transform transition-all duration-500 opacity-0 translate-y-2';
        toast.textContent = '✨ SAI-L6 已启动 ヾ(≧▽≦*)o';
        document.body.appendChild(toast);
     setTimeout(() => {
        toast.classList.remove('opacity-0', 'translate-y-2');
        }, 100);
        setTimeout(() => {
        toast.classList.add('opacity-0', 'translate-y-2');
        setTimeout(() => toast.remove(), 500);
        }, 3000);
    });

    const L6coder = document.getElementById('coder');
    L6coder.addEventListener('click', () => {
        url = 'https://ai.coludai.cn/api/chat/coder'; // 修改变量url的值为0
        console.log("已启动SAI-L6 Coder");
        ais.textContent = "你好我是SAI-L6 Coder\n我最擅长的就是写代码了，有什么代码上遇到的问题欢迎问我！O(∩_∩)O";
        titles.textContent = "SAI-L6 Coder";
        const toast = document.createElement('div');
        toast.className = 'fixed bottom-4 right-4 bg-gray-800 text-white px-6 py-3 !rounded-button shadow-lg transform transition-all duration-500 opacity-0 translate-y-2';
        toast.textContent = '✨ SAI-L6 Coder 已启动 O(∩_∩)O';
        document.body.appendChild(toast);
        setTimeout(() => {
        toast.classList.remove('opacity-0', 'translate-y-2');
        }, 100);
        setTimeout(() => {
        toast.classList.add('opacity-0', 'translate-y-2');
        setTimeout(() => toast.remove(), 500);
        }, 3000);
    });


  const chatContainer = document.querySelector('.chat-container');
  const userInput = document.getElementById('user-input');
  const sendBtn = document.getElementById('send-btn');

  sendBtn.addEventListener('click', () => {
      const userMessage = userInput.value.trim();
      window.mesag = userMessage ;
      if (userMessage) {
          addMessage('user', userMessage);
          userInput.value = '';
          respondToMessage(userMessage);
      }
  });

  userInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
          sendBtn.click();
      }
  });

  function addMessage(sender, message) {
      const messageElement = document.createElement('div');
      messageElement.classList.add('message', 'flex', 'items-start', 'mb-4');
      messageElement.style.maxWidth = '100%';

      if (sender === 'user') {
          messageElement.classList.add('justify-end');
          messageElement.innerHTML = `
          <br>
              <div style="width:11rem;"></div>
              <div class="bg-secondary rounded-lg p-3" style="padding: 0.75rem; background-color: #ffffff17;">
                  <p class="text-sm">${message}</p>
              </div>
          `;
      } else if (sender === 'thinking'){
        messageElement.innerHTML = `
        <div class="bg-secondary rounded-lg p-3" style=" background-color: #ffffff17;">
       
            <h3>
             <i class="fas fa-brain mr-1"></i> 正在深度思考...
</h3>
            

 ${message}
        </div>
    `;
      } else {
     
          messageElement.innerHTML = `
              <div style="margin-right:0; width: 31px;height: 2rem;"  class="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center mr-2">
                  <img src="https://sai.coludai.cn/assets/hexagon-CFv8sjr3.svg" width="18px" style="color: white;">
              </div>
              <div class="bg-secondary rounded-lg p-3" style="max-width:89%;padding: 0.75rem; background-color: 0;">
                  <p class="text-sm">${message}
</p>
                  
<br>
<button onclick="speakText('${message}')"  class="volume" >
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style="
    width: 16px;
    margin-top: -27px;
"><g fill="none"><path fill="#ffffff" d="M4.158 13.93a3.75 3.75 0 0 1 0-3.86a1.5 1.5 0 0 1 .993-.7l1.693-.339a.45.45 0 0 0 .258-.153L9.17 6.395c1.182-1.42 1.774-2.129 2.301-1.938S12 5.572 12 7.42v9.162c0 1.847 0 2.77-.528 2.962c-.527.19-1.119-.519-2.301-1.938L7.1 15.122a.45.45 0 0 0-.257-.153L5.15 14.63a1.5 1.5 0 0 1-.993-.7"></path><path stroke="#ffffff" stroke-linecap="round" stroke-width="2" d="M14.536 8.464a5 5 0 0 1 .027 7.044m4.094-9.165a8 8 0 0 1 .044 11.27"></path></g></svg>
         </button>  
              </div>
          `;
      }

      chatContainer.appendChild(messageElement);
      chatContainer.scrollTop = chatContainer.scrollHeight;
  }

  function respondToMessage(message) {

    // 获取当前日期并格式化为 YYYY-MM-DD 格式
    function getCurrentDate() {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
// 获取id为me的输入框
const inputElement = document.getElementById('user-input');

// 获取输入框的内容
const inputValue = inputElement.value;
    // Token操作
        // 获取当前日期
        const currentDate = getCurrentDate();
        console.log("当前日期:", currentDate);

        // 使用 MD5 加密日期并取前六位
        const dateMd5 = md5(currentDate);
        const dateMd5FirstSix = dateMd5.substring(0, 6);
        console.log("日期的 MD5 前六位:", dateMd5FirstSix);

        // 构造新的字符串并加密
        const newString = `${window.mesag}${dateMd5FirstSix}`;
        const token = md5(newString);
        console.log("最终的 Token:", token);

        // 将 token 保存到全局变量
        window.token = token;
        console.log("Token 已保存到全局变量:", window.token);

var myHeaders = new Headers();
myHeaders.append("ca", "c9b3f395-f8e6-47f4-98c0-64b5ac6fc1f0 ");
myHeaders.append("Content-Type", "application/json");
console.log(window.mesag);
var raw = JSON.stringify({
   "prompt": window.mesag,
   "token": window.token,
   "stream": false
});

var requestOptions = {
   method: 'POST',
   headers: myHeaders,
   body: raw,
   redirect: 'follow'
};

fetch(url, requestOptions)
.then(response => {
    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }
    return response.json(); // 假设返回的是 JSON 格式
})
   .then(result => {

    console.log(result);

    if (result && result.Thinking) {
        console.log("Thinking:", result.Thinking);
        addMessage('thinking', marked.parse(result.Thinking)); // 假设 thinking
        addMessage('ai', marked.parse(result.output)); // 假设 addMessage 是用来显示消息的函数
    } else {
        console.log("结果中没有 Thinking 字段:", result);
    

    if (result && result.output) {
        console.log("Output 内容:", result.output);
        addMessage('ai', marked.parse(result.output)); // 假设 addMessage 是用来显示消息的函数
    } else {
        console.log("结果中没有 output 字段:", result);
    }}
})
   .catch(error => addMessage('ai', '回答超时。'));



};
});