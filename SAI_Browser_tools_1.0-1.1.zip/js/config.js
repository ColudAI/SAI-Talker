// 全局变量
window.AskSai = {
    model: 1,//1:SAI-L6,2:SAI-L6 Coder,3:SAI-L6 Reasoner
    helper:false,//是否启用无障碍朗读模式
    help_sai:true,//是否启用问SAI按钮
    tag_sai:true//是否启用问SAI右键方式
};

// 访问全局变量
console.log('模型名称:',window.AskSai.model);
console.log('无障碍:',window.AskSai.helper);