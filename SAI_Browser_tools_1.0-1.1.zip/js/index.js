      // 打开对话框
      function openRateDialog() {
        document.getElementById('rateDialog').showModal();
    }

    // popup.js
document.addEventListener("DOMContentLoaded", () => {
const selectedTextElement = document.getElementById('selected-text');
const inputTextElement = document.getElementById('user-input');
const askSaiBtn = document.getElementById('ask-sai-btn');

chrome.storage.sync.get('selectedText', ({ selectedText }) => {
    if (selectedText) {
        selectedTextElement.textContent = selectedText;
        inputTextElement.value = selectedText;
    }
});
});