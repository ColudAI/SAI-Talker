document.addEventListener('mouseup', function() {
    const selection = window.getSelection().toString().trim();
    if (selection) {
        // 获取鼠标位置
        const selectedText = window.getSelection().toString().trim();
        const rect = window.getSelection().getRangeAt(0).getBoundingClientRect();
        const button = document.createElement('button');
        button.textContent = '问SAI';
        button.style.position = 'absolute';
        button.style.top = `${rect.bottom + window.scrollY}px`;
        button.style.left = `${rect.right + window.scrollX}px`;
        button.style.zIndex = '999999';
        button.style.padding = '2px 7px';
        button.style.fontSize = '16px';
        button.style.fontWeight = 'bold';
        button.style.background = 'rgb(255 255 255)';
        button.style.color = '#607D8B';
        button.style.border = '2px solid #607D8B';
        button.style.borderRadius = '6px';
        button.style.cursor = 'pointer';
        button.style.boxShadow = '0 2px 4px rgb(164 164 164 / 52%)';


          chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            if (message.text) {
                chrome.storage.sync.set({ selectedText: message.text });
                chrome.tabs.create({ url: chrome.runtime.getURL("popup.html") });
            }
        });


        button.addEventListener('click', () => {
            // 使用 chrome.storage
            chrome.storage.sync.get('selectedText', (result) => {
                if (result.selectedText) {
                    console.log("选中的文本内容:", result.selectedText);
                    chrome.tabs.create({ url: chrome.runtime.getURL("popup.html") });
                } else {
                    console.log("与SAI随时对话：你没有选中文本内容或脚本出错。");
                    const toast = document.createElement('div');
                    toast.style = `position: absolute;
    top: 7px;
    background: #607D8B;
    border-radius: 3px;
    color: #fff;
    padding: 6px 15px 8px;transition-property: all;
    transition-timing-function: cubic-bezier(0.4,0,0.2,1);
    transition-duration: 150ms;    transition-duration: .5s`;
                    toast.className = 'fixed bottom-4 tosa right-4 bg-gray-800 text-white px-6 py-3 !rounded-button shadow-lg transform transition-all duration-500 opacity-0 translate-y-2';
                    toast.textContent = '❌ 你没有选中文本内容 3S后自动关闭';
                    document.body.appendChild(toast);
                      setTimeout(() => {
                    toast.classList.remove('opacity-0', 'translate-y-2');
                    }, 100);
                    setTimeout(() => {
                    toast.classList.add('opacity-0', 'translate-y-2');
                    setTimeout(() => toast.remove(), 500);
                    }, 3000);
                }
            });
        });

      

        document.body.appendChild(button);

        // 监听鼠标移动事件，如果鼠标移出按钮范围，移除按钮
        const removeButton = () => {
            if (!window.getSelection().toString().trim()) {
                document.body.removeChild(button);
                document.removeEventListener('mousemove', removeButton);
                document.removeEventListener('mousedown', removeButton);
            }
        };

        document.addEventListener('mousemove', removeButton);
        document.addEventListener('mousedown', removeButton);
    }
});