
document.querySelectorAll('.toggle-switch').forEach(toggle => {
    toggle.addEventListener('click', () => {
    const dot = toggle.querySelector('.toggle-dot');
    if (toggle.classList.contains('bg-primary')) {
    toggle.classList.remove('bg-primary');
    toggle.classList.add('bg-gray-200');
    dot.style.transform = 'translateX(0)';
    } else {
    toggle.classList.remove('bg-gray-200');
    toggle.classList.add('bg-primary');
    dot.style.transform = 'translateX(24px)';
    }
    });
    });
    const dropdown = document.querySelector('.relative.inline-block');
    const dropdownContent = dropdown.querySelector('.absolute');
    dropdown.addEventListener('click', () => {
    dropdownContent.classList.toggle('hidden');
    });
    document.addEventListener('click', (e) => {
    if (!dropdown.contains(e.target)) {
    dropdownContent.classList.add('hidden');
    }
    });
    dropdownContent.querySelectorAll('div').forEach(option => {
    option.addEventListener('click', () => {
    dropdown.querySelector('span').textContent = option.textContent;
    dropdownContent.classList.add('hidden');
    });
    });
    document.querySelector('.update-btn').addEventListener('click', () => {
    const toast = document.createElement('div');
    toast.className = 'fixed bottom-4 right-4 bg-gray-800 text-white px-6 py-3 !rounded-button shadow-lg transform transition-all duration-500 opacity-0 translate-y-2';
    toast.textContent = '✨ 设置保存完成 ( •̀ ω •́ )✧';
    document.body.appendChild(toast);
    setTimeout(() => {
    toast.classList.remove('opacity-0', 'translate-y-2');
    }, 100);
    setTimeout(() => {
    toast.classList.add('opacity-0', 'translate-y-2');
    setTimeout(() => toast.remove(), 500);
    }, 3000);
    });